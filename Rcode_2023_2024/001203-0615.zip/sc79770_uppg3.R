####uppgift3####
library(lubridate)
new_license <- function(issued,date = NULL){
  new_license_10 <- c("AM","A1","A2","A","B","BE")
  new_license_5 <- c("C1","C","C1E","CE","D1","D1E","D","DE")
  if(length(issued) == 1){
    if(names(issued)%in%new_license_5){
      expire_days <- dmy(issued) + years(5)
    }
    if(names(issued)%in%new_license_10){
      expire_days <- dmy(issued) + years(10)
    }
  }
  if(length(issued) > 1){
    if(all(names(issued)%in%new_license_10)){
      expire_days <- max(dmy(issued)) + years(10)
    }else if(all(names(issued)%in%new_license_5)){
      expire_days <- max(dmy(issued)) + years(5)
    }else{
      expire_days <- max(dmy(issued)) + years(5)
    }
  }
  res <- list(expire_date = expire_days,
              num_days = as.numeric(as.duration(interval(date,expire_days)))/(60*60*24))
  return(res)
}
