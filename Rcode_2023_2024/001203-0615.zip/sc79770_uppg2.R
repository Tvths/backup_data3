####Uppgift2####
library(dplyr)
expected_matrix <- function(observed){
  if(!is.matrix(observed)) stop("Input needs to be a matrix!")
  if(!is.numeric(observed)) stop("Input needs to be numeric!")
  
  for (i in 1:length(observed[1,])){
    for (j in 1:length(observed[,1])){
      observed[i,j] <- sum(observed[i,])*sum(observed[,j])/sum(observed)
    }
  }
  return(observed)
}
