####uppgift1####

data_structure <- function(type = NULL){
  
  if(type == "vector"){
    res <-c("Jag","Gillar","R")
  }else if(type == "list"){
    res <- list(Vektor = c(1,2,3,5,7,11),
                Matris = matrix(c("TRUE","TRUE","TRUE","TRUE","FALSE","FALSE","FALSE","FALSE"),nrow = 2, byrow = TRUE),
                Text = c("Jag Gillar R!"))
  }else if(type == "data.frame"){
    res <- data.frame(Namn = c("Josef","Hugo","Emma","Filip","Annika"),
                      Placering = c(4,5,3,2,1),
                      Resultat = c(52,54,34,20,5),
                      Glad = c("Nej","Ja","Nej","Ja","Ja"))
  }else if(type == "matrix"){
    res <- matrix(c(2,3,5,7,11,13),nrow = 3,ncol = 2)
  }else{
    res <- c("Felaktig typ")
  }
  return(res)
}

